package com.htw.db;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DbConnection {

    private Connection connection;
    public DbConnection() {
        try {
            this.connection = this.connect();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public List<Trivia> selectAll() {
        String sql = "SELECT id, question, options, answer FROM trivia";
        List<Trivia> triviaList = new ArrayList<>();
        Statement stmt = null;
        try {
            stmt = connection.createStatement();

            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                Trivia trivia = new Trivia();
                trivia.setId(rs.getInt("id"));
                trivia.setQuestion(rs.getString("question"));
                trivia.setOptions(rs.getString("options"));
                trivia.setAnswer(rs.getString("answer"));
                triviaList.add(trivia);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return triviaList;
    }

    public Trivia selectById(int id){
        List<Trivia> triviaList = this.selectAll();
        for (Trivia t: triviaList) {
            if (t.getId() == id){
                return t;
            }
        }
        return null;
    }

    public List<String> getRemainingQuestions (List<Integer> ids){
        List<String> results = new ArrayList<>();
        List<Trivia> triviaList = this.selectAll();
        for (Trivia t: triviaList){
            if(!ids.contains(t.getId())){
                results.add(t.getQuestion());
            }
        }

        return results;
    }

    private Connection connect() throws SQLException {
        Connection conn = null;
        String url = "jdbc:sqlite:C:\\Users\\vzhang\\htw\\db\\htw.db";


       return DriverManager.getConnection(url);
    }

}