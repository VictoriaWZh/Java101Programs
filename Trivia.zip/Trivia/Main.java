package com.htw;

import com.htw.db.DbConnection;
import com.htw.db.Trivia;

import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        DbConnection dbConnection = new DbConnection();
        List<Integer> alreadyAsked = new ArrayList<>();
        alreadyAsked.add(3);
        alreadyAsked.add(4);
        alreadyAsked.add(5);
        List<String> remaining = dbConnection.getRemainingQuestions(alreadyAsked);

        for(String q: remaining) {
            System.out.println(q);
        }
    }
}
